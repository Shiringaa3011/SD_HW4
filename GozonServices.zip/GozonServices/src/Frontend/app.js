const API_BASE = '';

function switchTab(tabId) {
    const parent = event.target.closest('.card');

    parent.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.remove('active');
    });

    parent.querySelectorAll('.tab').forEach(btn => {
        btn.classList.remove('active');
    });

    document.getElementById(tabId).classList.add('active');
    event.target.classList.add('active');
}

function showMessage(text, type = 'info') {
    const messageDiv = document.getElementById('message');
    messageDiv.textContent = text;
    messageDiv.className = `message ${type}`;
    messageDiv.style.display = 'block';
}

function showResult(data) {
    const resultDiv = document.getElementById('result');
    resultDiv.textContent = JSON.stringify(data, null, 2);
}

function setLoading(buttonId, isLoading) {
    const button = document.getElementById(buttonId);
    if (!button) return;
    
    if (isLoading) {
        button.disabled = true;
        button.classList.add('loading');
        button.setAttribute('data-original-text', button.textContent);
        button.textContent = 'Загрузка...';
    } else {
        button.disabled = false;
        button.classList.remove('loading');
        const originalText = button.getAttribute('data-original-text');
        if (originalText) {
            button.textContent = originalText;
        }
    }
}

function updateStatusIndicator(elementId, isHealthy) {
    const indicator = document.getElementById(elementId);
    if (indicator) {
        indicator.className = `status-indicator ${isHealthy ? 'status-healthy' : 'status-unhealthy'}`;
    }
}

async function checkGatewayHealth() {
    try {
        const response = await fetch('/health');
        const data = await response.json();
        showResult(data);
        updateStatusIndicator('gateway-status', response.ok);
        showMessage(`Gateway: ${data.status}`, response.ok ? 'success' : 'error');
    } catch (error) {
        showMessage(`Gateway недоступен: ${error.message}`, 'error');
        updateStatusIndicator('gateway-status', false);
    }
}

async function createOrder() {
    const userId = document.getElementById('userId').value;
    const amount = document.getElementById('orderAmount').value;
    const description = document.getElementById('orderDescription').value;
    const currency = document.getElementById('orderCurrency').value;
    
    if (!userId || !amount || !description) {
        showMessage('Заполните все обязательные поля', 'error');
        return;
    }
    
    try {
        setLoading('createOrderBtn', true);
        
        const response = await fetch(`/api/orders?userId=${userId}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                amount: parseFloat(amount),
                description: description,
                currency: currency
            })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showMessage('Заказ успешно создан!', 'success');
            if (data.orderId) {
                document.getElementById('orderId').value = data.orderId;
            }
        } else {
            showMessage(`Ошибка: ${data.error || 'Неизвестная ошибка'}`, 'error');
        }
        
        showResult(data);
    } catch (error) {
        showMessage(`Сетевая ошибка: ${error.message}`, 'error');
    } finally {
        setLoading('createOrderBtn', false);
    }
}

async function getOrders() {
    const userId = document.getElementById('viewUserId').value;
    const page = document.getElementById('orderPage').value || 0;
    const pageSize = document.getElementById('orderPageSize').value || 20;
    
    if (!userId) {
        showMessage('Введите ID пользователя', 'error');
        return;
    }
    
    try {
        setLoading('getOrdersBtn', true);
        
        const response = await fetch(`/api/orders?userId=${userId}&page=${page}&pageSize=${pageSize}`);
        const data = await response.json();
        
        if (response.ok) {
            showMessage(`Найдено заказов: ${Array.isArray(data) ? data.length : 'неизвестно'}`, 'success');
        } else {
            showMessage(`Ошибка: ${data.error || 'Неизвестная ошибка'}`, 'error');
        }
        
        showResult(data);
    } catch (error) {
        showMessage(`Сетевая ошибка: ${error.message}`, 'error');
    } finally {
        setLoading('getOrdersBtn', false);
    }
}

async function getOrderStatus() {
    const orderId = document.getElementById('orderId').value;
    const userId = document.getElementById('viewUserId').value;
    
    if (!orderId || !userId) {
        showMessage('Введите ID заказа и ID пользователя', 'error');
        return;
    }
    
    try {
        const response = await fetch(`/api/orders/${orderId}?userId=${userId}`);
        const data = await response.json();
        
        if (response.ok) {
            showMessage('Статус заказа получен', 'success');
        } else {
            showMessage(`Ошибка: ${data.error || 'Неизвестная ошибка'}`, 'error');
        }
        
        showResult(data);
    } catch (error) {
        showMessage(`Сетевая ошибка: ${error.message}`, 'error');
    }
}

async function createAccount() {
    const userId = document.getElementById('accountUserId').value;
    const currency = document.getElementById('accountCurrency').value;
    
    if (!userId) {
        showMessage('Введите ID пользователя', 'error');
        return;
    }
    
    try {
        setLoading('createAccountBtn', true);
        
        const response = await fetch(`/api/accounts?userId=${userId}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                currency: currency
            })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showMessage('Счёт успешно создан!', 'success');
        } else {
            showMessage(`Ошибка: ${data.error || 'Неизвестная ошибка'}`, 'error');
        }
        
        showResult(data);
    } catch (error) {
        showMessage(`Сетевая ошибка: ${error.message}`, 'error');
    } finally {
        setLoading('createAccountBtn', false);
    }
}

async function getBalance() {
    const userId = document.getElementById('balanceUserId').value;
    
    if (!userId) {
        showMessage('Введите ID пользователя', 'error');
        return;
    }
    
    try {
        setLoading('getBalanceBtn', true);
        
        const response = await fetch(`/api/accounts/balance?userId=${userId}`);
        const data = await response.json();
        
        if (response.ok) {
            showMessage(`Баланс получен`, 'success');
        } else {
            showMessage(`Ошибка: ${data.error || 'Неизвестная ошибка'}`, 'error');
        }
        
        showResult(data);
    } catch (error) {
        showMessage(`Сетевая ошибка: ${error.message}`, 'error');
    } finally {
        setLoading('getBalanceBtn', false);
    }
}

async function topUpAccount() {
    const userId = document.getElementById('balanceUserId').value;
    const amount = document.getElementById('depositAmount').value;
    const description = document.getElementById('depositDescription').value;
    
    if (!userId || !amount) {
        showMessage('Введите ID пользователя и сумму', 'error');
        return;
    }
    
    try {
        setLoading('topUpBtn', true);
        
        const response = await fetch(`/api/accounts/deposit?userId=${userId}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                amount: parseFloat(amount),
                description: description || 'Пополнение баланса'
            })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showMessage('Счёт успешно пополнен!', 'success');
            setTimeout(getBalance, 1000);
        } else {
            showMessage(`Ошибка: ${data.error || 'Неизвестная ошибка'}`, 'error');
        }
        
        showResult(data);
    } catch (error) {
        showMessage(`Сетевая ошибка: ${error.message}`, 'error');
    } finally {
        setLoading('topUpBtn', false);
    }
}

document.addEventListener('DOMContentLoaded', () => {
    showMessage('Система готова к работе! Выберите действие из меню выше.', 'success');

    const healthButtons = document.querySelectorAll('.health-buttons button');
    if (healthButtons[1]) {
        healthButtons[1].onclick = checkOrderServiceHealth;
    }
    if (healthButtons[2]) {
        healthButtons[2].onclick = checkPaymentServiceHealth;
    }

    setTimeout(checkGatewayHealth, 1000);
});