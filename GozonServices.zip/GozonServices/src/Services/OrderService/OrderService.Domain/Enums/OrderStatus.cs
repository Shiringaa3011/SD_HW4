﻿using System;

namespace OrderService.Domain.Enums
{
    public enum OrderStatus
    {
        New = 1,

        Finished = 2,

        Cancelled = 3
    }
}
