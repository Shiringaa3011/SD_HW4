namespace PaymentsService.Application.Dtos
{
    public record TopUpAccountDto(Guid UserId, decimal Amount);

}
