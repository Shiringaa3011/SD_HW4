namespace PaymentsService.Application.Dtos
{
    public record CreateAccountDto(Guid UserId);

}
