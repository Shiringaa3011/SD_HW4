﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using PaymentsService.Application.Dtos;
using PaymentsService.Application.Ports;
using Common.Messaging.Abstractions.Interfaces;
using System.Text.Json;

namespace PaymentsService.Infrastructure.Workers
{
    public class PaymentOutboxWorker(
        IServiceProvider serviceProvider,
        ILogger<PaymentOutboxWorker> logger,
        IOptions<OutboxWorkerOptions> options,
        IMessagePublisher publisher) : BackgroundService
    {
        private readonly IServiceProvider _serviceProvider = serviceProvider;
        private readonly ILogger<PaymentOutboxWorker> _logger = logger;
        private readonly OutboxWorkerOptions _options = options.Value;
        private readonly IMessagePublisher _publisher = publisher;

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation("PaymentOutboxWorker запущен");

            while (!stoppingToken.IsCancellationRequested)
            {
                try
                {
                    await ProcessOutboxMessagesAsync(stoppingToken);
                    await Task.Delay(_options.PollingInterval, stoppingToken);
                }
                catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
                {
                    break;
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Ошибка в PaymentOutboxWorker");
                    await Task.Delay(TimeSpan.FromSeconds(10), stoppingToken);
                }
            }

            _logger.LogInformation("PaymentOutboxWorker остановлен");
        }

        private async Task ProcessOutboxMessagesAsync(CancellationToken ct)
        {
            using IServiceScope scope = _serviceProvider.CreateScope();
            IPaymentOutboxRepository outboxRepository = scope.ServiceProvider.GetRequiredService<IPaymentOutboxRepository>();

            List<OutboxMessage> pendingMessages = await outboxRepository.GetPendingMessagesAsync(_options.BatchSize, ct);

            if (!pendingMessages.Any())
            {
                _logger.LogDebug("Нет ожидающих сообщений в outbox");
                return;
            }

            _logger.LogInformation("Найдено {Count} ожидающих сообщений. Начинаю отправку...", pendingMessages.Count);

            foreach (OutboxMessage message in pendingMessages)
            {
                try
                {
                    _logger.LogWarning(message.Body);


                    await ProcessSingleMessageAsync(message, outboxRepository, ct);

                    _logger.LogDebug("Сообщение {MessageId} обработано", message.MessageId);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Ошибка обработки сообщения {MessageId}", message.MessageId);
                }
            }

            _logger.LogInformation("Итерация обработки outbox завершена");
        }

        private async Task ProcessSingleMessageAsync(
            OutboxMessage message,
            IPaymentOutboxRepository outboxRepository,
            CancellationToken ct)
        {
            if (string.IsNullOrEmpty(message.Topic))
            {
                _logger.LogWarning("Сообщение {MessageId} не имеет topic (очереди)", message.MessageId);
                return;
            }

            if (string.IsNullOrEmpty(message.Body))
            {
                _logger.LogWarning("Сообщение {MessageId} пустое", message.MessageId);
                return;
            }

            _logger.LogDebug("Обработка outbox сообщения: ID={Id}, Type={Type}, Topic={Topic}",
                message.Id, message.Type, message.Topic);

            PaymentResultDto? paymentResult;
            try
            {
                paymentResult = JsonSerializer.Deserialize<PaymentResultDto>(message.Body);

                if (paymentResult == null)
                {
                    _logger.LogError("Не удалось десериализовать PaymentResultDto из сообщения {MessageId}", message.MessageId);
                    return;
                }
            }
            catch (JsonException ex)
            {
                _logger.LogError(ex, "Неверный JSON формат в сообщении {MessageId}", message.MessageId);
                return;
            }

            try
            {
                string processorId = $"{Environment.MachineName}-{Guid.NewGuid()}";
                _logger.LogWarning("Сообщение {MessageId} TryAcquireForSendingAsync", message.MessageId);

                bool acquired = await outboxRepository.TryAcquireForSendingAsync(
                    message.MessageId, ct);
                _logger.LogWarning("Сообщение {MessageId} TryAcquireForSendingAsync после", message.MessageId);

                if (!acquired)
                {
                    _logger.LogWarning("Сообщение {MessageId} уже отправляется другим процессом", message.MessageId);
                    return;
                }

                _logger.LogWarning("Отправляю результат платежа для заказа {OrderId} в очередь {Queue}",
                    paymentResult.OrderId, message.Topic);

                await _publisher.PublishAsync(
                    message: paymentResult,
                    routingKey: message.Topic,
                    exchange: "orders-exchange",
                    headers: new Dictionary<string, object>
                    {
                        ["x-message-type"] = "PaymentResult",
                        ["x-correlation-id"] = paymentResult.MessageId ?? string.Empty,
                        ["x-outbox-id"] = message.Id.ToString(),
                        ["x-original-type"] = message.Type,
                        ["x-timestamp"] = DateTimeOffset.UtcNow.ToUnixTimeSeconds(),
                        ["x-order-id"] = paymentResult.OrderId.ToString()
                    },
                    ct: ct);

                await outboxRepository.MarkAsPublishedAsync(message.MessageId, ct);

                _logger.LogWarning("Результат платежа отправлен. OrderId={OrderId}, Success={Success}",
                    paymentResult.OrderId, paymentResult.Success);

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка отправки в RabbitMQ для сообщения {MessageId}, заказа {OrderId}",
                    message.MessageId, paymentResult?.OrderId);
            
                try
                {
                    await outboxRepository.ReleaseAsync(message.Id, ct);
                }
                catch (Exception releaseEx)
                {
                    _logger.LogError(releaseEx, "Ошибка при освобождении сообщения {MessageId}", message.MessageId);
                }
            

                throw;
            }
        }
    }

    public class OutboxWorkerOptions
    {
        public int BatchSize { get; set; } = 100;
        public TimeSpan PollingInterval { get; set; } = TimeSpan.FromSeconds(5);
    }
}