﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using PaymentsService.Application.Ports;
using PaymentsService.Domain.Entities;
using PaymentsService.Infrastructure.Persistence.Entities;
using Npgsql;

namespace PaymentsService.Infrastructure.Persistence.Repositories
{
    public class WithdrawalRepository(
        PaymentsDbContext dbContext,
        ILogger<WithdrawalRepository> logger) : IWithdrawalRepository
    {
        private readonly PaymentsDbContext _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
        private readonly ILogger<WithdrawalRepository> _logger = logger ?? throw new ArgumentNullException(nameof(logger));

        public async Task AddAsync(Withdrawal withdrawal, CancellationToken ct = default)
        {
            _logger.LogDebug("Adding withdrawal for payment {PaymentId}", withdrawal.PaymentId);

            WithdrawalDbModel dbModel = WithdrawalDbModel.FromDomain(withdrawal);

            try
            {
                _ = await _dbContext.Withdrawals.AddAsync(dbModel, ct);
                _logger.LogInformation("Withdrawal added for payment {PaymentId}. Withdrawal ID: {WithdrawalId}",
                    withdrawal.PaymentId, withdrawal.Id);
            }
            catch (DbUpdateException ex) when (IsUniqueConstraintViolation(ex))
            {
                _logger.LogWarning("Withdrawal already exists for payment {PaymentId}", withdrawal.PaymentId);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error adding withdrawal for payment {PaymentId}", withdrawal.PaymentId);
                throw;
            }
        }

        public async Task<Withdrawal?> GetByPaymentIdAsync(Guid paymentId, CancellationToken ct = default)
        {
            _logger.LogDebug("Getting withdrawal for payment {PaymentId}", paymentId);

            try
            {
                WithdrawalDbModel? dbModel = await _dbContext.Withdrawals
                    .AsNoTracking()
                    .Where(w => w.PaymentId == paymentId)
                    .OrderByDescending(w => w.CreatedAt)
                    .FirstOrDefaultAsync(ct);

                if (dbModel == null)
                {
                    _logger.LogDebug("Withdrawal not found for payment {PaymentId}", paymentId);
                    return null;
                }

                return dbModel.ToDomainEntity();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting withdrawal for payment {PaymentId}", paymentId);
                throw;
            }
        }

        private bool IsUniqueConstraintViolation(DbUpdateException ex)
        {
            return ex.InnerException is PostgresException pgEx &&
                   pgEx.SqlState == PostgresErrorCodes.UniqueViolation;
        }
    }
}