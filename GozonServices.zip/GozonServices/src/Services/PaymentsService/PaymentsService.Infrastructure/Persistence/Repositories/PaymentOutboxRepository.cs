﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Npgsql;
using PaymentsService.Application.Dtos;
using PaymentsService.Application.Ports;
using PaymentsService.Infrastructure.Persistence.Entities;

namespace PaymentsService.Infrastructure.Persistence.Repositories
{
    public class PaymentOutboxRepository(
        PaymentsDbContext dbContext,
        ILogger<PaymentOutboxRepository> logger) : IPaymentOutboxRepository
    {
        private readonly PaymentsDbContext _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
        private readonly ILogger<PaymentOutboxRepository> _logger = logger ?? throw new ArgumentNullException(nameof(logger));

        public async Task<bool> TryAcquireForSendingAsync(Guid messageId, CancellationToken ct)
        {
            string sql = @"
            UPDATE outbox_messages 
            SET status = 'Sending',
                version = version + 1
            WHERE message_id = @messageId 
              AND status = 'Pending'";

            NpgsqlParameter[] parameters =
            [
            new NpgsqlParameter("messageId", messageId),
            new NpgsqlParameter("lockedAt", DateTimeOffset.UtcNow),
            ];

            int rowsAffected = await _dbContext.Database.ExecuteSqlRawAsync(sql, parameters);
            _logger.LogWarning(rowsAffected.ToString());

            return rowsAffected > 0;
        }

        public async Task AddAsync(OutboxMessage message, CancellationToken ct = default)
        {
            _logger.LogDebug("Adding message to outbox. CorrelationId: {CorrelationId}, Type: {Type}",
                message.CorrelationId, message.Type);

            try
            {
                bool exists = await _dbContext.OutboxMessages
                    .AsNoTracking()
                    .AnyAsync(m => m.CorrelationId == message.CorrelationId, ct);

                if (exists)
                {
                    _logger.LogDebug("Outbox message already exists for correlation: {CorrelationId}",
                        message.CorrelationId);
                    return;
                }

                OutboxMessageDbModel dbModel = OutboxMessageDbModel.FromDomain(message);
                _ = await _dbContext.OutboxMessages.AddAsync(dbModel, ct);

                _logger.LogInformation("Message added to outbox. CorrelationId: {CorrelationId}, MessageId: {MessageId}",
                    message.CorrelationId, message.MessageId);
            }
            catch (DbUpdateException ex) when (IsUniqueConstraintViolation(ex))
            {
                _logger.LogDebug("Outbox message already exists (unique constraint): {CorrelationId}",
                    message.CorrelationId);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error adding message to outbox. CorrelationId: {CorrelationId}",
                    message.CorrelationId);
                throw;
            }
        }

        public async Task MarkAsPublishedAsync(Guid messageId, CancellationToken ct = default)
        {
            _logger.LogDebug("Marking outbox message as published: {MessageId}", messageId);

            try
            {
                string sql = @"
            UPDATE outbox_messages 
            SET status = 'Sent',
                sent_at = @sentAt,
                version = version + 1
            WHERE message_id = @messageId 
              AND status IN ('Pending', 'Sending')"; 

                NpgsqlParameter[] parameters =
                [
                new NpgsqlParameter("messageId", messageId),
                new NpgsqlParameter("sentAt", DateTimeOffset.UtcNow)
                ];

                int rowsAffected = await _dbContext.Database.ExecuteSqlRawAsync(sql, parameters);

                _logger.LogWarning("SQL executed. Rows affected: {Rows} for message {MessageId}",
                    rowsAffected, messageId);

                if (rowsAffected > 0)
                {
                    _logger.LogInformation("Outbox message marked as published: {MessageId}", messageId);
                }
                else
                {
                    _logger.LogWarning(
                        "Outbox message not found or already sent: {MessageId}. " +
                        "Check if message exists and has correct status (Pending/Sending).",
                        messageId);

                    await LogMessageDetailsAsync(messageId, ct);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error marking outbox message as published: {MessageId}", messageId);
                throw;
            }
        }

        public async Task<OutboxMessage?> FindByMessageIdAsync(string messageId, CancellationToken ct = default)
        {
            _logger.LogDebug("Finding outbox message by MessageId: {MessageId}", messageId);

            if (!Guid.TryParse(messageId, out Guid guid))
            {
                _logger.LogWarning("Invalid MessageId format: {MessageId}", messageId);
                return null;
            }

            try
            {
                OutboxMessageDbModel? dbModel = await _dbContext.OutboxMessages
                    .AsNoTracking()
                    .FirstOrDefaultAsync(m => m.MessageId == guid, ct);

                if (dbModel == null)
                {
                    _logger.LogDebug("Outbox message not found: {MessageId}", messageId);
                    return null;
                }

                return dbModel.ToDomainEntity();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error finding outbox message by MessageId: {MessageId}", messageId);
                throw;
            }
        }

        public async Task<List<OutboxMessage>> GetPendingMessagesAsync(int batchSize, CancellationToken ct)
        {
            _logger.LogDebug("Getting pending outbox messages, batch size: {BatchSize}", batchSize);

            try
            {
                List<OutboxMessage> messages = await _dbContext.OutboxMessages
                    .Where(m => m.Status == "Pending")
                    .OrderBy(m => m.CreatedAt)
                    .Take(batchSize)
                    .AsNoTracking()
                    .Select(m => m.ToDomainEntity())
                    .ToListAsync(ct);

                _logger.LogDebug("Found {Count} pending outbox messages", messages.Count);
                return messages;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting pending outbox messages");
                throw;
            }
        }

        public async Task ReleaseAsync(Guid messageId, CancellationToken ct = default)
        {
            _logger.LogDebug("Releasing outbox message: {MessageId}", messageId);

            try
            {
                string sql = @"
            UPDATE outbox_messages 
            SET status = 'Pending',
                locked_at = NULL,
                processor_id = NULL,
                retry_count = retry_count + 1,
                error_message = CASE 
                    WHEN retry_count >= @maxRetries THEN 'Max retry attempts exceeded'
                    ELSE error_message 
                END,
                version = version + 1
            WHERE message_id = @messageId 
              AND status = 'Sending'";

                NpgsqlParameter[] parameters =
                [
                new NpgsqlParameter("messageId", messageId),
                new NpgsqlParameter("maxRetries", 5)
                ];

                int rowsAffected = await _dbContext.Database.ExecuteSqlRawAsync(sql, parameters);

                if (rowsAffected > 0)
                {
                    _logger.LogInformation("Outbox message released for retry: {MessageId}", messageId);

                    await LogRetryCountAsync(messageId, ct);
                }
                else
                {
                    _logger.LogWarning(
                        "Outbox message {MessageId} not found or not in 'Sending' state. " +
                        "It might have been already processed.",
                        messageId);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error releasing outbox message: {MessageId}", messageId);
                throw;
            }
        }

        private async Task LogMessageDetailsAsync(Guid messageId, CancellationToken ct)
        {
            try
            {
                OutboxMessageDbModel? message = await _dbContext.OutboxMessages
                    .FirstOrDefaultAsync(m => m.MessageId == messageId, ct);

                if (message != null)
                {
                    _logger.LogWarning(
                        "Message {MessageId} details: Status={Status}, Created={CreatedAt}, " +
                        "SentAt={SentAt}, RetryCount={RetryCount}",
                        messageId, message.Status, message.CreatedAt,
                        message.SentAt, message.RetryCount);
                }
                else
                {
                    _logger.LogWarning("Message {MessageId} not found in database", messageId);
                }
            }
            catch (Exception ex)
            {
                _logger.LogWarning("Could not get details for message {MessageId}: {Error}",
                    messageId, ex.Message);
            }
        }

        private async Task LogRetryCountAsync(Guid messageId, CancellationToken ct)
        {
            try
            {
                var messageInfo = await _dbContext.OutboxMessages
                    .Where(m => m.MessageId == messageId)
                    .Select(m => new { m.RetryCount, m.ErrorMessage, m.Status })
                    .FirstOrDefaultAsync(ct);

                if (messageInfo != null)
                {
                    _logger.LogDebug(
                        "Message {MessageId} retry info: RetryCount={RetryCount}, Status={Status}, Error={Error}",
                        messageId, messageInfo.RetryCount, messageInfo.Status, messageInfo.ErrorMessage);

                    if (messageInfo.RetryCount >= 5 && messageInfo.Status == "Pending")
                    {
                        await MarkAsFailedAsync(messageId,
                            $"Max retry count (5) exceeded. Last error: {messageInfo.ErrorMessage}");
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogDebug("Could not log retry count for message {MessageId}: {Error}",
                    messageId, ex.Message);
            }
        }

        private async Task MarkAsFailedAsync(Guid messageId, string error)
        {
            _logger.LogDebug("Marking outbox message as failed: {MessageId}, error: {Error}",
                messageId, error);

            try
            {
                _ = await _dbContext.Database.ExecuteSqlRawAsync(@"
                    UPDATE outbox_messages 
                    SET status = 
                        CASE 
                            WHEN retry_count >= 5 THEN 'Failed'
                            ELSE 'Pending'
                        END,
                        failed_at = {1},
                        error_message = {2},
                        version = version + 1
                    WHERE message_id = {0}",
                    messageId, DateTimeOffset.UtcNow, error);

                _logger.LogInformation("Outbox message marked as failed: {MessageId}", messageId);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error marking outbox message as failed: {MessageId}", messageId);
                throw;
            }
        }

        private bool IsUniqueConstraintViolation(DbUpdateException ex)
        {
            return ex.InnerException is PostgresException pgEx &&
                   pgEx.SqlState == PostgresErrorCodes.UniqueViolation;
        }
    }
}