﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using PaymentsService.Application.Ports;
using PaymentsService.Domain.Entities;
using PaymentsService.Infrastructure.Persistence.Entities;
using Npgsql;

namespace PaymentsService.Infrastructure.Persistence.Repositories
{
    public class PaymentRepository(
        PaymentsDbContext dbContext,
        ILogger<PaymentRepository> logger) : IPaymentRepository
    {
        private readonly PaymentsDbContext _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
        private readonly ILogger<PaymentRepository> _logger = logger ?? throw new ArgumentNullException(nameof(logger));

        public async Task<Payment?> GetByOrderIdAsync(Guid orderId, CancellationToken ct = default)
        {
            _logger.LogDebug("Getting payment for order {OrderId}", orderId);

            try
            {
                PaymentDbModel? dbModel = await _dbContext.Payments
                    .AsNoTracking()
                    .FirstOrDefaultAsync(p => p.OrderId == orderId, ct);

                if (dbModel == null)
                {
                    _logger.LogDebug("Payment not found for order {OrderId}", orderId);
                    return null;
                }

                return dbModel.ToDomainEntity();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting payment for order {OrderId}", orderId);
                throw;
            }
        }

        public async Task AddAsync(Payment payment, CancellationToken ct = default)
        {
            _logger.LogDebug("Adding payment for order {OrderId}", payment.OrderId);

            PaymentDbModel dbModel = PaymentDbModel.FromDomain(payment);

            try
            {
                bool existing = await _dbContext.Payments
                    .AsNoTracking()
                    .AnyAsync(p => p.OrderId == payment.OrderId, ct);

                if (existing)
                {
                    _logger.LogWarning("Payment already exists for order {OrderId}", payment.OrderId);
                    throw new InvalidOperationException($"Payment already exists for order {payment.OrderId}");
                }

                _ = await _dbContext.Payments.AddAsync(dbModel, ct);
                _logger.LogInformation("Payment added for order {OrderId}. Payment ID: {PaymentId}",
                    payment.OrderId, payment.Id);
            }
            catch (DbUpdateException ex) when (IsUniqueConstraintViolation(ex))
            {
                _logger.LogWarning("Payment already exists (unique constraint) for order {OrderId}",
                    payment.OrderId);
                throw new InvalidOperationException($"Payment already exists for order {payment.OrderId}", ex);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error adding payment for order {OrderId}", payment.OrderId);
                throw;
            }
        }

        public async Task<bool> TryUpdateWithVersionAsync(
            Payment payment,
            int expectedVersion,
            CancellationToken ct = default)
        {
            _logger.LogDebug("Attempting to update payment {PaymentId} with expected version {ExpectedVersion}",
                payment.Id, expectedVersion);

            try
            {
                PaymentDbModel dbModel = PaymentDbModel.FromDomain(payment);

                string sql = @"
                    UPDATE payments 
                    SET status = @status,
                        completed_at = @completedAt,
                        version = version + 1
                    WHERE id = @id 
                      AND version = @expectedVersion";

                NpgsqlParameter[] parameters =
                [
                    new NpgsqlParameter("status", payment.Status.ToString()),
                    new NpgsqlParameter("completedAt", (object?)payment.CompletedAt ?? DBNull.Value),
                    new NpgsqlParameter("id", payment.Id),
                    new NpgsqlParameter("expectedVersion", expectedVersion)
                ];

                int rowsAffected = await _dbContext.Database.ExecuteSqlRawAsync(sql, parameters);
                bool success = rowsAffected > 0;

                if (success)
                {
                    _logger.LogDebug("Payment {PaymentId} updated successfully", payment.Id);
                }
                else
                {
                    _logger.LogWarning("Version mismatch when updating payment {PaymentId}. Expected: {ExpectedVersion}",
                        payment.Id, expectedVersion);
                }

                return success;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating payment {PaymentId}", payment.Id);
                throw;
            }
        }

        private bool IsUniqueConstraintViolation(DbUpdateException ex)
        {
            return ex.InnerException is PostgresException pgEx &&
                   pgEx.SqlState == PostgresErrorCodes.UniqueViolation;
        }
    }
}