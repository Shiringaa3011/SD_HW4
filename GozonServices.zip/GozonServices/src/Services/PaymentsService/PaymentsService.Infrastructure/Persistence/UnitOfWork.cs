﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using Microsoft.Extensions.Logging;
using PaymentsService.Application.Ports;
using System.Data;

namespace PaymentsService.Infrastructure.Persistence
{
    public class UnitOfWork(
        PaymentsDbContext dbContext,
        ILogger<UnitOfWork> logger) : IUnitOfWork
    {
        private readonly PaymentsDbContext _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
        private IDbContextTransaction? _currentTransaction;
        private bool _disposed = false;
        private readonly ILogger<UnitOfWork> _logger = logger ?? throw new ArgumentNullException(nameof(logger));

        public async Task BeginTransactionAsync(CancellationToken ct)
        {
            if (_currentTransaction != null)
            {
                _logger.LogWarning("Transaction already started");
                throw new InvalidOperationException("Transaction already started");
            }

            try
            {
                _currentTransaction = await _dbContext.Database.BeginTransactionAsync(
                    IsolationLevel.ReadCommitted,
                    ct);

                _logger.LogDebug("Transaction started. Transaction ID: {TransactionId}",
                    _currentTransaction.TransactionId);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to begin transaction");
                throw;
            }
        }

        public async Task CommitTransactionAsync(CancellationToken ct)
        {
            if (_currentTransaction == null)
            {
                _logger.LogWarning("No active transaction to commit");
                throw new InvalidOperationException("No active transaction to commit");
            }

            try
            {
                // Сначала сохраняем изменения в контексте
                _ = await _dbContext.SaveChangesAsync(ct);

                // Затем коммитим транзакцию
                await _currentTransaction.CommitAsync(ct);

                _logger.LogInformation("Transaction committed successfully. Transaction ID: {TransactionId}",
                    _currentTransaction.TransactionId);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to commit transaction");
                await RollbackTransactionAsync(ct);
                throw;
            }
            finally
            {
                await DisposeTransactionAsync();
            }
        }

        public async Task RollbackTransactionAsync(CancellationToken ct)
        {
            if (_currentTransaction == null)
            {
                _logger.LogWarning("No active transaction to rollback");
                return;
            }

            try
            {
                await _currentTransaction.RollbackAsync(ct);
                _logger.LogInformation("Transaction rolled back. Transaction ID: {TransactionId}",
                    _currentTransaction.TransactionId);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to rollback transaction");
                throw;
            }
            finally
            {
                await DisposeTransactionAsync();
            }
        }

        public async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        {
            try
            {
                int result = await _dbContext.SaveChangesAsync(cancellationToken);
                _logger.LogDebug("Saved {Count} changes to database", result);
                return result;
            }
            catch (DbUpdateConcurrencyException ex)
            {
                _logger.LogError(ex, "Concurrency exception while saving changes");
                throw new InvalidOperationException("Concurrency conflict occurred", ex);
            }
            catch (DbUpdateException ex)
            {
                _logger.LogError(ex, "Database update exception while saving changes");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unexpected error while saving changes");
                throw;
            }
        }

        private async Task DisposeTransactionAsync()
        {
            if (_currentTransaction != null)
            {
                await _currentTransaction.DisposeAsync();
                _currentTransaction = null;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                    _currentTransaction?.Dispose();
                    _dbContext?.Dispose();
                }
                _disposed = true;
            }
        }

        public async ValueTask DisposeAsync()
        {
            await DisposeAsyncCore();
            Dispose(false);
            GC.SuppressFinalize(this);
        }

        protected virtual async ValueTask DisposeAsyncCore()
        {
            if (_currentTransaction != null)
            {
                await _currentTransaction.DisposeAsync();
            }

            if (_dbContext != null)
            {
                await _dbContext.DisposeAsync();
            }
        }
    }
}