﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.OpenApi;
using PaymentsService.Application;
using PaymentsService.Application.Dtos;
using PaymentsService.Application.Ports;
using PaymentsService.Application.UseCases;
using PaymentsService.Domain.Exceptions;
using PaymentsService.Infrastructure;
using PaymentsService.Infrastructure.Persistence;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace PaymentsService.WebApi
{
    public class Program
    {
        public static async Task Main(string[] args)
        {
            WebApplicationBuilder builder = WebApplication.CreateBuilder(args);

            _ = builder.Configuration
                .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                .AddEnvironmentVariables();

            ConfigureServices(builder.Services, builder.Configuration);

            WebApplication app = builder.Build();
            _ = await WaitForDatabaseAsync(app.Services);
            ConfigureMiddleware(app);

            Console.WriteLine($"Payments Service запущен");
            Console.WriteLine($"Swagger: http://localhost:8080/swagger");

            await app.RunAsync();
        }

        private static void ConfigureServices(IServiceCollection services, IConfiguration configuration)
        {
            _ = services.AddControllers()
                .AddJsonOptions(options =>
                {
                    options.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
                    options.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
                    options.JsonSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
                });

            // Swagger
            _ = services.AddEndpointsApiExplorer();
            _ = services.AddSwaggerGen(c => c.SwaggerDoc("v1",
                new OpenApiInfo
                {
                    Title = "Payments Service API",
                    Version = "v1",
                    Description = "Сервис управления платежами и счетами"
                }));

            // Регистрация зависимостей
            _ = services.AddApplication();
            _ = services.AddInfrastructure(configuration);

            // Логирование
            _ = services.AddLogging(logging =>
            {
                _ = logging.AddConsole();
                _ = logging.AddDebug();
            });

            _ = services.AddCors(options => options.AddPolicy("AllowAll", policy =>
                policy.AllowAnyOrigin()
                      .AllowAnyMethod()
                      .AllowAnyHeader()));
        }

        private static void ConfigureMiddleware(WebApplication app)
        {
            _ = app.UseRouting();

            // Обработчик ошибок
            _ = app.UseExceptionHandler(appError => appError.Run(async context =>
            {
                context.Response.StatusCode = 500;
                context.Response.ContentType = "application/json";

                var errorResponse = new
                {
                    Message = "Internal server error",
                    RequestId = context.TraceIdentifier,
                    Timestamp = DateTime.UtcNow
                };

                string json = JsonSerializer.Serialize(errorResponse);
                byte[] bytes = Encoding.UTF8.GetBytes(json);

                await context.Response.Body.WriteAsync(bytes, 0, bytes.Length);
                await context.Response.Body.FlushAsync();
            }));

            _ = app.UseSwagger();
            _ = app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "Payments Service API v1"));

            _ = app.UseCors("AllowAll");

            // Health check endpoint
            _ = app.MapGet("/health", () => new
            {
                status = "healthy",
                service = "payments-service",
                timestamp = DateTime.UtcNow,
                version = "1.0.0"
            });

            // Эндпоинты
            ConfigureEndpoints(app);

            _ = app.MapControllers();
        }

        private static void ConfigureEndpoints(WebApplication app)
        {
            // 1. Создание счёта
            _ = app.MapPost("/api/accounts", async (
                [FromQuery] Guid userId,
                [FromBody] CreateAccountRequest request,
                [FromServices] CreateAccountUseCase createAccountUseCase) =>
            {
                if (userId == Guid.Empty)
                {
                    return Results.BadRequest(new { Error = "User ID is required" });
                }

                try
                {
                    await createAccountUseCase.HandleAsync(new CreateAccountDto(userId));

                    return Results.Ok(new
                    {
                        UserId = userId,
                        request.Currency,
                        Message = "Account created or already exists",
                        Timestamp = DateTime.UtcNow
                    });
                }
                catch (Exception ex)
                {
                    return Results.Problem(
                        detail: ex.Message,
                        statusCode: 500,
                        title: "Failed to create account");
                }
            })
            .WithName("CreateAccount")
            .Produces(StatusCodes.Status200OK)
            .Produces(StatusCodes.Status400BadRequest)
            .Produces(StatusCodes.Status500InternalServerError);

            // 2. Пополнение счёта
            _ = app.MapPost("/api/accounts/deposit", async (
                [FromQuery] Guid userId,
                [FromBody] TopUpAccountRequest request,
                [FromServices] TopUpAccountUseCase topUpAccountUseCase) =>
            {
                if (userId == Guid.Empty)
                {
                    return Results.BadRequest(new { Error = "User ID is required" });
                }

                if (request.Amount <= 0)
                {
                    return Results.BadRequest(new { Error = "Amount must be greater than zero" });
                }

                try
                {
                    await topUpAccountUseCase.HandleAsync(new TopUpAccountDto(userId, request.Amount));

                    return Results.Ok(new
                    {
                        UserId = userId,
                        request.Amount,
                        Message = "Account topped up successfully",
                        Timestamp = DateTime.UtcNow
                    });
                }
                catch (AccountNotFoundException ex)
                {
                    return Results.NotFound(new { Error = ex.Message });
                }
                catch (Exception ex)
                {
                    return Results.Problem(
                        detail: ex.Message,
                        statusCode: 500,
                        title: "Failed to top up account");
                }
            })
            .WithName("TopUpAccount")
            .Produces(StatusCodes.Status200OK)
            .Produces(StatusCodes.Status400BadRequest)
            .Produces(StatusCodes.Status404NotFound)
            .Produces(StatusCodes.Status500InternalServerError);

            // 3. Просмотр баланса счёта
            _ = app.MapGet("/api/accounts/balance", async (
                [FromQuery] Guid userId,
                [FromServices] GetBalanceUseCase getBalanceUseCase) =>
            {
                if (userId == Guid.Empty)
                {
                    return Results.BadRequest(new { Error = "User ID is required" });
                }

                try
                {
                    AccountBalanceDto balance = await getBalanceUseCase.HandleAsync(userId);

                    return Results.Ok(new
                    {
                        UserId = userId,
                        balance.Balance,
                        balance.Currency,
                        Timestamp = DateTime.UtcNow
                    });
                }
                catch (AccountNotFoundException ex)
                {
                    return Results.NotFound(new { Error = ex.Message });
                }
                catch (Exception ex)
                {
                    return Results.Problem(
                        detail: ex.Message,
                        statusCode: 500,
                        title: "Failed to get balance");
                }
            })
            .WithName("GetBalance")
            .Produces(StatusCodes.Status200OK)
            .Produces(StatusCodes.Status400BadRequest)
            .Produces(StatusCodes.Status404NotFound)
            .Produces(StatusCodes.Status500InternalServerError);

            // 4. Проверка базы данных
            _ = app.MapGet("/check-db", async ([FromServices] PaymentsDbContext dbContext) =>
            {
                try
                {
                    bool canConnect = await dbContext.Database.CanConnectAsync();
                    return Results.Ok(new
                    {
                        DatabaseConnected = canConnect,
                        Time = DateTime.UtcNow
                    });
                }
                catch (Exception ex)
                {
                    return Results.Problem(
                        detail: ex.Message,
                        statusCode: 500,
                        title: "Database connection failed");
                }
            });
        }

        private static async Task<bool> WaitForDatabaseAsync(IServiceProvider services, int maxRetries = 30)
        {
            using IServiceScope scope = services.CreateScope();
            PaymentsDbContext dbContext = scope.ServiceProvider.GetRequiredService<PaymentsDbContext>();
            ILogger<Program> logger = scope.ServiceProvider.GetRequiredService<ILogger<Program>>();

            for (int i = 0; i < maxRetries; i++)
            {
                try
                {
                    logger.LogInformation("Database connection attempt {Attempt}/{Max}", i + 1, maxRetries);
                    bool canConnect = await dbContext.Database.CanConnectAsync();
                    if (canConnect)
                    {
                        logger.LogInformation("Database connection successful");
                        return true;
                    }
                }
                catch (Exception ex)
                {
                    logger.LogWarning("Database connection failed: {Message}", ex.Message);
                }

                await Task.Delay(2000);
            }

            logger.LogError("Failed to connect to database after {MaxRetries} attempts", maxRetries);
            return false;
        }
    }

    public record CreateAccountRequest(string Currency = "RUB");

    public record TopUpAccountRequest(
        decimal Amount,
        string? Description = null);
}